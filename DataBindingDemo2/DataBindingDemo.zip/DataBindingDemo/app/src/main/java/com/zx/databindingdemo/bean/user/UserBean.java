package com.zx.databindingdemo.bean.user;

/**
 * 作者： 周旭 on 2017年10月12日 0012.
 * 邮箱：374952705@qq.com
 * 博客：http://www.jianshu.com/u/56db5d78044d
 */

public class UserBean {
    private String content;

    public UserBean(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
