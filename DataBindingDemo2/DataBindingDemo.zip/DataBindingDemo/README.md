# DataBindingDemo
DataBinding系列详解

请移步到我的个人博客查看详细说明

[DataBinding系列（一）：DataBinding初认识](http://www.jianshu.com/p/53925ccb900e)

[DataBinding系列（二）：DataBinding的基本用法](http://www.jianshu.com/p/70316eb4e0f8)

[DataBinding系列（三）：RecyclerView中使用DataBinding](http://www.jianshu.com/p/4d30efa6b500)

